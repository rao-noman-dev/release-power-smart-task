-- Phase 3 application schema for EMPTY databases only. Historical migrations then apply in order.
-- Derived from the confirmed schema initialization SQL; never run on a populated database.
CREATE TABLE "audit_logs" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer,
        "action" text NOT NULL,
        "details" text,
        "ip_address" text,
        "created_at" timestamp DEFAULT now()
);

CREATE TABLE "daily_summary_runs" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "local_date" text NOT NULL,
        "status" text DEFAULT 'pending' NOT NULL,
        "attempt_count" integer DEFAULT 0 NOT NULL,
        "next_attempt_at" timestamp with time zone DEFAULT now() NOT NULL,
        "processing_started_at" timestamp with time zone,
        "sent_at" timestamp with time zone,
        "last_error" text,
        "created_at" timestamp with time zone DEFAULT now(),
        "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE "email_verification_tokens" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "email" text NOT NULL,
        "token_hash" text NOT NULL,
        "expires_at" timestamp with time zone NOT NULL,
        "used_at" timestamp with time zone,
        "created_at" timestamp DEFAULT now(),
        CONSTRAINT "email_verification_tokens_token_hash_unique" UNIQUE("token_hash")
);

CREATE TABLE "external_notices" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "external_source_id" integer,
        "external_message_id" text NOT NULL,
        "sender" text NOT NULL,
        "subject" text NOT NULL,
        "snippet" text NOT NULL,
        "full_content" text,
        "notice_type" text DEFAULT 'general' NOT NULL,
        "course_code" text,
        "detected_deadline" text,
        "has_converted_to_task" boolean DEFAULT false,
        "converted_task_id" integer,
        "received_at" text NOT NULL,
        "created_at" timestamp DEFAULT now()
);

CREATE TABLE "external_sources" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "source_type" text NOT NULL,
        "account_email" text NOT NULL,
        "display_name" text NOT NULL,
        "is_connected" boolean DEFAULT true,
        "last_sync_at" text,
        "status" text DEFAULT 'active',
        "created_at" timestamp DEFAULT now()
);

CREATE TABLE "notification_deliveries" (
        "id" serial PRIMARY KEY NOT NULL,
        "provider" text,
        "provider_message_id" text,
        "idempotency_key" text,
        "provider_event_at" timestamp with time zone,
        "user_id" integer NOT NULL,
        "task_id" integer,
        "recipient_email" text NOT NULL,
        "subject" text NOT NULL,
        "email_type" text NOT NULL,
        "delivery_status" text DEFAULT 'queued' NOT NULL,
        "provider_response" text,
        "error_message" text,
        "retry_count" integer DEFAULT 0,
        "sent_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE "notifications" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "task_id" integer,
        "scheduled_job_id" integer,
        "source" text DEFAULT 'system' NOT NULL,
        "category" text DEFAULT 'Task Reminders' NOT NULL,
        "title" text NOT NULL,
        "description" text NOT NULL,
        "is_read" boolean DEFAULT false,
        "read_at" text,
        "action_url" text,
        "external_source_link" text,
        "created_at" timestamp DEFAULT now(),
        CONSTRAINT "notifications_scheduled_job_id_unique" UNIQUE("scheduled_job_id")
);

CREATE TABLE "oauth_connections" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "source_id" integer NOT NULL,
        "provider" text NOT NULL,
        "account_email" text NOT NULL,
        "access_token_encrypted" text NOT NULL,
        "refresh_token_encrypted" text NOT NULL,
        "expires_at" timestamp with time zone NOT NULL,
        "scopes" text NOT NULL,
        "sync_cursor" text,
        "sync_lease_at" timestamp with time zone,
        "last_synced_at" timestamp with time zone,
        "status" text DEFAULT 'active' NOT NULL,
        "created_at" timestamp with time zone DEFAULT now(),
        "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE "oauth_states" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "provider" text NOT NULL,
        "state_hash" text NOT NULL,
        "expires_at" timestamp with time zone NOT NULL,
        "used_at" timestamp with time zone,
        "created_at" timestamp DEFAULT now(),
        CONSTRAINT "oauth_states_state_hash_unique" UNIQUE("state_hash")
);

CREATE TABLE "processed_webhook_events" (
        "id" serial PRIMARY KEY NOT NULL,
        "provider" text NOT NULL,
        "event_id" text NOT NULL,
        "event_type" text NOT NULL,
        "resource_id" text,
        "processed_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE "push_subscriptions" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "endpoint" text NOT NULL,
        "p256dh" text NOT NULL,
        "auth" text NOT NULL,
        "created_at" timestamp with time zone DEFAULT now(),
        CONSTRAINT "push_subscriptions_endpoint_unique" UNIQUE("endpoint")
);

CREATE TABLE "reminder_rules" (
        "id" serial PRIMARY KEY NOT NULL,
        "task_id" integer NOT NULL,
        "label" text NOT NULL,
        "offset_minutes" integer NOT NULL,
        "is_active" boolean DEFAULT true,
        "created_at" timestamp DEFAULT now()
);

CREATE TABLE "saved_task_filters" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "name" text NOT NULL,
        "definition" text NOT NULL,
        "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE "scheduled_jobs" (
        "id" serial PRIMARY KEY NOT NULL,
        "task_id" integer NOT NULL,
        "user_id" integer NOT NULL,
        "scheduled_for" text NOT NULL,
        "reminder_type" text NOT NULL,
        "status" text DEFAULT 'pending' NOT NULL,
        "retry_count" integer DEFAULT 0,
        "sent_at" text,
        "processing_started_at" timestamp with time zone,
        "web_push_attempted_at" timestamp with time zone,
        "last_attempt_at" timestamp with time zone,
        "idempotency_key" text,
        "created_at" timestamp DEFAULT now()
);

CREATE TABLE "subscriptions" (
        "id" serial PRIMARY KEY NOT NULL,
        "billing_provider" text,
        "provider_customer_id" text,
        "provider_subscription_id" text,
        "provider_price_id" text,
        "current_period_end" timestamp with time zone,
        "user_id" integer NOT NULL,
        "plan" text DEFAULT 'free' NOT NULL,
        "status" text DEFAULT 'active' NOT NULL,
        "started_at" text NOT NULL,
        "expires_at" text,
        "created_at" timestamp DEFAULT now(),
        CONSTRAINT "subscriptions_user_id_unique" UNIQUE("user_id")
);

CREATE TABLE "subtasks" (
        "id" serial PRIMARY KEY NOT NULL,
        "task_id" integer NOT NULL,
        "title" text NOT NULL,
        "is_completed" boolean DEFAULT false,
        "position" integer DEFAULT 0,
        "created_at" timestamp DEFAULT now()
);

CREATE TABLE "task_categories" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer,
        "name" text NOT NULL,
        "color" text DEFAULT '#6366f1' NOT NULL,
        "icon" text DEFAULT 'Folder',
        "is_default" boolean DEFAULT false,
        "created_at" timestamp DEFAULT now()
);

CREATE TABLE "task_history" (
        "id" serial PRIMARY KEY NOT NULL,
        "task_id" integer,
        "user_id" integer NOT NULL,
        "action" text NOT NULL,
        "details" text,
        "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE "task_templates" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "name" text NOT NULL,
        "definition" text NOT NULL,
        "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE "tasks" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "title" text NOT NULL,
        "description" text DEFAULT '',
        "category_id" integer,
        "category_name" text DEFAULT 'General',
        "priority" text DEFAULT 'medium' NOT NULL,
        "status" text DEFAULT 'pending' NOT NULL,
        "due_date" text NOT NULL,
        "start_date" text,
        "timezone" text DEFAULT 'Asia/Karachi',
        "notes" text DEFAULT '',
        "tags" text DEFAULT '[]',
        "is_recurring" boolean DEFAULT false,
        "recurring_rule" text DEFAULT 'none',
        "recurring_interval_days" integer DEFAULT 1,
        "overdue_interval_hours" integer DEFAULT 3,
        "snoozed_until" text,
        "completed_at" text,
        "trashed_at" timestamp with time zone,
        "pre_trash_status" text,
        "source_notice_id" integer,
        "spawned_from_task_id" integer,
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now()
);

CREATE TABLE "user_profiles" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "timezone" text DEFAULT 'Asia/Karachi' NOT NULL,
        "notification_email" text NOT NULL,
        "secondary_email" text,
        "secondary_email_verified" boolean DEFAULT false,
        "quiet_hours_start" text DEFAULT '22:00',
        "quiet_hours_end" text DEFAULT '07:00',
        "daily_summary_enabled" boolean DEFAULT true,
        "daily_summary_time" text DEFAULT '08:00',
        "max_daily_notifications" integer DEFAULT 25,
        "email_alerts_enabled" boolean DEFAULT true NOT NULL,
        "in_app_alerts_enabled" boolean DEFAULT true NOT NULL,
        "web_push_enabled" boolean DEFAULT false NOT NULL,
        "critical_bypass_quiet_hours" boolean DEFAULT false NOT NULL,
        "digest_mode" boolean DEFAULT false NOT NULL,
        "weekly_digest_enabled" boolean DEFAULT false NOT NULL,
        "weekly_digest_time" text DEFAULT '09:00' NOT NULL,
        "preferred_language" text DEFAULT 'en',
        "onboarding_completed" boolean DEFAULT false,
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now(),
        CONSTRAINT "user_profiles_user_id_unique" UNIQUE("user_id")
);

CREATE TABLE "users" (
        "id" serial PRIMARY KEY NOT NULL,
        "uid" text NOT NULL,
        "email" text NOT NULL,
        "display_name" text,
        "photo_url" text,
        "role" text DEFAULT 'user' NOT NULL,
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now(),
        CONSTRAINT "users_uid_unique" UNIQUE("uid")
);

CREATE TABLE "weekly_digest_runs" (
        "id" serial PRIMARY KEY NOT NULL,
        "user_id" integer NOT NULL,
        "week_start" text NOT NULL,
        "status" text DEFAULT 'processing' NOT NULL,
        "attempt_count" integer DEFAULT 0 NOT NULL,
        "processing_started_at" timestamp with time zone,
        "sent_at" timestamp with time zone
);

ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;
ALTER TABLE "daily_summary_runs" ADD CONSTRAINT "daily_summary_runs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "email_verification_tokens" ADD CONSTRAINT "email_verification_tokens_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "external_notices" ADD CONSTRAINT "external_notices_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "external_notices" ADD CONSTRAINT "external_notices_external_source_id_external_sources_id_fk" FOREIGN KEY ("external_source_id") REFERENCES "public"."external_sources"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "external_notices" ADD CONSTRAINT "external_notices_converted_task_id_tasks_id_fk" FOREIGN KEY ("converted_task_id") REFERENCES "public"."tasks"("id") ON DELETE set null ON UPDATE no action;
ALTER TABLE "external_sources" ADD CONSTRAINT "external_sources_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "notification_deliveries" ADD CONSTRAINT "notification_deliveries_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "notification_deliveries" ADD CONSTRAINT "notification_deliveries_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE set null ON UPDATE no action;
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE set null ON UPDATE no action;
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_scheduled_job_id_scheduled_jobs_id_fk" FOREIGN KEY ("scheduled_job_id") REFERENCES "public"."scheduled_jobs"("id") ON DELETE set null ON UPDATE no action;
ALTER TABLE "oauth_connections" ADD CONSTRAINT "oauth_connections_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "oauth_connections" ADD CONSTRAINT "oauth_connections_source_id_external_sources_id_fk" FOREIGN KEY ("source_id") REFERENCES "public"."external_sources"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "oauth_states" ADD CONSTRAINT "oauth_states_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "push_subscriptions" ADD CONSTRAINT "push_subscriptions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "reminder_rules" ADD CONSTRAINT "reminder_rules_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "saved_task_filters" ADD CONSTRAINT "saved_task_filters_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "scheduled_jobs" ADD CONSTRAINT "scheduled_jobs_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "scheduled_jobs" ADD CONSTRAINT "scheduled_jobs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "subtasks" ADD CONSTRAINT "subtasks_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "task_categories" ADD CONSTRAINT "task_categories_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "task_history" ADD CONSTRAINT "task_history_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE set null ON UPDATE no action;
ALTER TABLE "task_history" ADD CONSTRAINT "task_history_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "task_templates" ADD CONSTRAINT "task_templates_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_category_id_task_categories_id_fk" FOREIGN KEY ("category_id") REFERENCES "public"."task_categories"("id") ON DELETE set null ON UPDATE no action;
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_spawned_from_task_id_tasks_id_fk" FOREIGN KEY ("spawned_from_task_id") REFERENCES "public"."tasks"("id") ON DELETE set null ON UPDATE no action;
ALTER TABLE "user_profiles" ADD CONSTRAINT "user_profiles_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "weekly_digest_runs" ADD CONSTRAINT "weekly_digest_runs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
CREATE UNIQUE INDEX "daily_summary_runs_user_date_uq" ON "daily_summary_runs" USING btree ("user_id","local_date");
CREATE UNIQUE INDEX "external_notices_source_message_uq" ON "external_notices" USING btree ("external_source_id","external_message_id");
CREATE INDEX "notification_deliveries_user_sent_status_idx" ON "notification_deliveries" USING btree ("user_id","sent_at","delivery_status");
CREATE INDEX "notification_deliveries_provider_message_idx" ON "notification_deliveries" USING btree ("provider","provider_message_id");
CREATE UNIQUE INDEX "notification_deliveries_idempotency_uq" ON "notification_deliveries" USING btree ("idempotency_key");
CREATE UNIQUE INDEX "oauth_connections_user_provider_account_uq" ON "oauth_connections" USING btree ("user_id","provider","account_email");
CREATE UNIQUE INDEX "processed_webhook_events_provider_event_uq" ON "processed_webhook_events" USING btree ("provider","event_id");
CREATE INDEX "task_history_user_task_time_idx" ON "task_history" USING btree ("user_id","task_id","created_at");
CREATE UNIQUE INDEX "tasks_source_notice_uq" ON "tasks" USING btree ("source_notice_id");
CREATE UNIQUE INDEX "tasks_spawned_from_task_id_uq" ON "tasks" USING btree ("spawned_from_task_id");
CREATE UNIQUE INDEX "weekly_digest_runs_owner_week_uq" ON "weekly_digest_runs" USING btree ("user_id","week_start");
