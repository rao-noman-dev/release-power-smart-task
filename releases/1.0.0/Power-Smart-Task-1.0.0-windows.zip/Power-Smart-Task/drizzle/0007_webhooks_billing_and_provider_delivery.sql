ALTER TABLE notification_deliveries
  ADD COLUMN IF NOT EXISTS provider TEXT,
  ADD COLUMN IF NOT EXISTS provider_message_id TEXT,
  ADD COLUMN IF NOT EXISTS provider_event_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS notification_deliveries_provider_message_idx
  ON notification_deliveries(provider, provider_message_id)
  WHERE provider_message_id IS NOT NULL;

ALTER TABLE subscriptions
  ADD COLUMN IF NOT EXISTS billing_provider TEXT,
  ADD COLUMN IF NOT EXISTS provider_customer_id TEXT,
  ADD COLUMN IF NOT EXISTS provider_subscription_id TEXT,
  ADD COLUMN IF NOT EXISTS provider_price_id TEXT,
  ADD COLUMN IF NOT EXISTS current_period_end TIMESTAMPTZ;

CREATE UNIQUE INDEX IF NOT EXISTS subscriptions_provider_subscription_uq
  ON subscriptions(billing_provider, provider_subscription_id)
  WHERE provider_subscription_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS processed_webhook_events (
  id SERIAL PRIMARY KEY,
  provider TEXT NOT NULL,
  event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  resource_id TEXT,
  processed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT processed_webhook_events_provider_event_uq UNIQUE(provider, event_id)
);

ALTER TABLE notification_deliveries
  ADD COLUMN IF NOT EXISTS idempotency_key TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS notification_deliveries_idempotency_key_uq
  ON notification_deliveries(idempotency_key)
  WHERE idempotency_key IS NOT NULL;
