ALTER TABLE tasks ADD COLUMN IF NOT EXISTS recurring_interval_days INTEGER NOT NULL DEFAULT 1;

CREATE UNIQUE INDEX IF NOT EXISTS tasks_source_notice_uq ON tasks(source_notice_id);
