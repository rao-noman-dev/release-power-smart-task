-- Additive Phase 6 operations. No application data is dropped.
CREATE TABLE IF NOT EXISTS security_rate_buckets (
 bucket text NOT NULL, window_start timestamptz NOT NULL, count integer NOT NULL,
 expires_at timestamptz NOT NULL, PRIMARY KEY(bucket,window_start)
);
CREATE INDEX IF NOT EXISTS security_rate_expiry_idx ON security_rate_buckets(expires_at);
CREATE TABLE IF NOT EXISTS runtime_heartbeats (
 worker text PRIMARY KEY, instance_id text NOT NULL, state text NOT NULL,
 started_at timestamptz, finished_at timestamptz, last_success_at timestamptz,
 consecutive_failures integer NOT NULL DEFAULT 0, error_code text
);
ALTER TABLE users ADD COLUMN IF NOT EXISTS deletion_requested_at timestamptz;
CREATE TABLE IF NOT EXISTS account_deletion_jobs (
 id uuid PRIMARY KEY, user_id integer REFERENCES users(id) ON DELETE SET NULL,
 firebase_uid text NOT NULL UNIQUE, uid_hash text NOT NULL,
 state text NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','processing','retry','completed','blocked')),
 created_at timestamptz NOT NULL DEFAULT now(), next_attempt_at timestamptz NOT NULL DEFAULT now(),
 lease_until timestamptz, attempts integer NOT NULL DEFAULT 0, error_code text,
 ledger_written_at timestamptz, completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS deletion_jobs_pending_idx ON account_deletion_jobs(state,next_attempt_at);
CREATE TABLE IF NOT EXISTS privacy_erasure_tombstones (
 uid_hash text PRIMARY KEY, request_id uuid NOT NULL, erased_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS privacy_consent_records (
 id serial PRIMARY KEY, user_id integer REFERENCES users(id) ON DELETE CASCADE,
 policy_version text NOT NULL, purpose text NOT NULL, granted boolean NOT NULL,
 recorded_at timestamptz NOT NULL DEFAULT now()
);
-- Minimal financial records survive account erasure for operator-approved retention.
ALTER TABLE billing_invoices ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE billing_invoices DROP CONSTRAINT IF EXISTS billing_invoices_user_id_fkey;
ALTER TABLE billing_invoices ADD CONSTRAINT billing_invoices_user_id_fkey FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE billing_invoices ADD COLUMN IF NOT EXISTS erasure_reference uuid;
ALTER TABLE billing_invoices ADD COLUMN IF NOT EXISTS legal_hold boolean NOT NULL DEFAULT false;
-- Prevent new owned data from an in-flight request after the account has been frozen.
CREATE OR REPLACE FUNCTION pst_deny_erasing_owner() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE erased timestamptz;
BEGIN
 PERFORM pg_advisory_xact_lock(73505,NEW.user_id);
 SELECT deletion_requested_at INTO erased FROM users WHERE id=NEW.user_id FOR SHARE;
 IF erased IS NOT NULL THEN RAISE EXCEPTION 'ACCOUNT_ERASING: Account deletion requested' USING ERRCODE='42501'; END IF;
 RETURN NEW;
END $$;
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['tasks','external_sources','external_notices','oauth_connections','push_subscriptions','task_templates','saved_task_filters','billing_checkout_attempts'] LOOP
  EXECUTE format('DROP TRIGGER IF EXISTS pst_erasure_guard ON %I',t);
  EXECUTE format('CREATE TRIGGER pst_erasure_guard BEFORE INSERT ON %I FOR EACH ROW EXECUTE FUNCTION pst_deny_erasing_owner()',t);
 END LOOP;
END $$;

CREATE TABLE IF NOT EXISTS operations_alerts (
 code text PRIMARY KEY,last_attempt_at timestamptz,accepted_at timestamptz,
 failures integer NOT NULL DEFAULT 0,last_state text NOT NULL DEFAULT 'pending'
);
