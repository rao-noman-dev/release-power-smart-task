ALTER TABLE IF EXISTS scheduled_jobs
  ADD COLUMN IF NOT EXISTS last_attempt_at TIMESTAMPTZ;

UPDATE scheduled_jobs
SET last_attempt_at = COALESCE(processing_started_at, created_at, NOW())
WHERE last_attempt_at IS NULL;

CREATE INDEX IF NOT EXISTS scheduled_jobs_task_reminder_attempt_idx
  ON scheduled_jobs (task_id, reminder_type, created_at DESC);
