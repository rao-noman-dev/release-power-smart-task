-- Phase 5: additive billing schema. Existing tasks and provider records are preserved.
-- billing_plan_catalog is the SINGLE runtime source for UI, API, worker and DB limits.
CREATE TABLE IF NOT EXISTS billing_plan_catalog (
 id text PRIMARY KEY, definition jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO billing_plan_catalog (id, definition)
SELECT value->>'id', value FROM jsonb_array_elements($catalog$[
  {
    "id": "free",
    "name": "Free Starter",
    "available": true,
    "priceMinor": 0,
    "currency": "PKR",
    "interval": null,
    "limits": {
      "activeTasks": 30,
      "activeReminders": 5,
      "monthlyEmails": 30,
      "monthlyAi": 5,
      "mailboxes": 0
    },
    "features": {
      "advancedReminders": false,
      "webPush": false,
      "advancedAnalytics": false,
      "mailboxSync": false
    }
  },
  {
    "id": "pro_student",
    "name": "Pro Student / Personal",
    "available": true,
    "priceMinor": 49900,
    "currency": "PKR",
    "interval": "month",
    "limits": {
      "activeTasks": null,
      "activeReminders": null,
      "monthlyEmails": 300,
      "monthlyAi": 100,
      "mailboxes": 2
    },
    "features": {
      "advancedReminders": true,
      "webPush": true,
      "advancedAnalytics": true,
      "mailboxSync": true
    }
  },
  {
    "id": "business",
    "name": "Business",
    "available": false,
    "priceMinor": null,
    "currency": "PKR",
    "interval": null,
    "limits": {
      "activeTasks": 0,
      "activeReminders": 0,
      "monthlyEmails": 0,
      "monthlyAi": 0,
      "mailboxes": 0
    },
    "features": {
      "advancedReminders": false,
      "webPush": false,
      "advancedAnalytics": false,
      "mailboxSync": false
    }
  },
  {
    "id": "institution",
    "name": "Institution",
    "available": false,
    "priceMinor": null,
    "currency": "PKR",
    "interval": null,
    "limits": {
      "activeTasks": 0,
      "activeReminders": 0,
      "monthlyEmails": 0,
      "monthlyAi": 0,
      "mailboxes": 0
    },
    "features": {
      "advancedReminders": false,
      "webPush": false,
      "advancedAnalytics": false,
      "mailboxSync": false
    }
  }
]$catalog$::jsonb)
ON CONFLICT (id) DO NOTHING;
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS billing_environment text;
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS paid_through timestamptz;
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS payment_verified_at timestamptz;
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS grace_until timestamptz;
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS cancel_at_period_end boolean NOT NULL DEFAULT false;
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS last_provider_event_at timestamptz;
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS subscriptions_provider_binding_uq ON subscriptions (billing_provider,billing_environment,provider_subscription_id) WHERE provider_subscription_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS billing_grants (
 id serial PRIMARY KEY, user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 plan text NOT NULL CHECK (plan='pro_student'), expires_at timestamptz NOT NULL, revoked_at timestamptz,
 granted_by integer REFERENCES users(id) ON DELETE SET NULL, reason text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS billing_grants_owner_idx ON billing_grants(user_id);
CREATE TABLE IF NOT EXISTS billing_usage (
 user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE, month_key text NOT NULL,
 metric text NOT NULL CHECK (metric IN ('email','ai')), used integer NOT NULL DEFAULT 0 CHECK(used >= 0),
 updated_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(user_id,month_key,metric)
);
CREATE TABLE IF NOT EXISTS billing_usage_keys (
 user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE, metric text NOT NULL,
 idempotency_key text NOT NULL, month_key text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(user_id,metric,idempotency_key)
);
CREATE TABLE IF NOT EXISTS billing_checkout_attempts (
 reference text PRIMARY KEY, user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 request_key text NOT NULL, provider text NOT NULL, environment text NOT NULL,
 price_id text NOT NULL, amount_minor integer NOT NULL, currency text NOT NULL,
 status text NOT NULL DEFAULT 'creating', provider_session_id text, checkout_url text,
 provider_subscription_id text, created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL,
 UNIQUE(user_id,request_key)
);
CREATE UNIQUE INDEX IF NOT EXISTS billing_checkout_one_open_uq ON billing_checkout_attempts(user_id) WHERE status IN ('creating','pending','uncertain');
CREATE UNIQUE INDEX IF NOT EXISTS billing_checkout_subscription_uq ON billing_checkout_attempts(provider,environment,provider_subscription_id) WHERE provider_subscription_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS billing_events (
 id serial PRIMARY KEY, provider text NOT NULL, environment text NOT NULL, event_id text NOT NULL,
 payload jsonb NOT NULL, status text NOT NULL DEFAULT 'pending', attempts integer NOT NULL DEFAULT 0,
 next_attempt_at timestamptz NOT NULL DEFAULT now(), processed_at timestamptz, last_error text,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(provider,environment,event_id)
);
CREATE INDEX IF NOT EXISTS billing_events_pending_idx ON billing_events(status,next_attempt_at);
CREATE TABLE IF NOT EXISTS billing_invoices (
 id serial PRIMARY KEY, user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 provider text NOT NULL, environment text NOT NULL, provider_invoice_id text NOT NULL,
 provider_subscription_id text NOT NULL, amount_minor integer NOT NULL CHECK (amount_minor >= 0),
 currency text NOT NULL, status text NOT NULL, invoice_url text, receipt_url text,
 period_start timestamptz, period_end timestamptz, paid_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(provider,environment,provider_invoice_id)
);
CREATE INDEX IF NOT EXISTS billing_invoices_owner_idx ON billing_invoices(user_id,created_at);
CREATE TABLE IF NOT EXISTS billing_support_requests (
 id serial PRIMARY KEY, user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 invoice_id integer REFERENCES billing_invoices(id) ON DELETE SET NULL,
 kind text NOT NULL CHECK(kind IN ('refund','billing')), reason text NOT NULL, status text NOT NULL DEFAULT 'open',
 resolution text, handled_by integer REFERENCES users(id) ON DELETE SET NULL,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
-- No old 'active' or browser-written plan is trusted as payment evidence.
CREATE OR REPLACE FUNCTION pst_effective_plan(p_user integer) RETURNS text LANGUAGE plpgsql STABLE AS $$
DECLARE s subscriptions%ROWTYPE;
BEGIN
 IF EXISTS(SELECT 1 FROM billing_grants WHERE user_id=p_user AND plan='pro_student' AND revoked_at IS NULL AND expires_at>now()) THEN RETURN 'pro_student'; END IF;
 SELECT * INTO s FROM subscriptions WHERE user_id=p_user;
 IF s.plan='pro_student' AND s.billing_provider IN ('stripe','safepay') AND s.payment_verified_at IS NOT NULL
    AND s.status IN ('active','past_due','cancelled') AND
    (s.paid_through>now() OR (s.status='past_due' AND s.grace_until>now())) THEN RETURN 'pro_student'; END IF;
 RETURN 'free';
END $$;
CREATE OR REPLACE FUNCTION pst_plan_definition(p_user integer) RETURNS jsonb LANGUAGE plpgsql STABLE AS $$
DECLARE result jsonb;
BEGIN
 SELECT definition INTO result FROM billing_plan_catalog WHERE id=pst_effective_plan(p_user);
 IF result IS NULL THEN RAISE EXCEPTION 'PLAN_CONFIG_MISSING: Billing catalog unavailable; no entitlement granted.'; END IF;
 RETURN result;
END $$;
-- Account-level advisory locks serialize capacity changes across API processes/workers.
CREATE OR REPLACE FUNCTION pst_enforce_task_capacity() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE lim integer; used integer; rem_lim integer; own_rules integer; active_rules integer;
BEGIN
 IF NEW.status IN ('completed','cancelled','archived','trashed') OR NEW.trashed_at IS NOT NULL THEN RETURN NEW; END IF;
 IF TG_OP='UPDATE' THEN
   IF NEW.user_id=OLD.user_id AND OLD.status NOT IN ('completed','cancelled','archived','trashed') AND OLD.trashed_at IS NULL THEN RETURN NEW; END IF;
 END IF;
 PERFORM pg_advisory_xact_lock(73505,NEW.user_id);
 lim := (pst_plan_definition(NEW.user_id)->'limits'->>'activeTasks')::integer;
 SELECT count(*) INTO used FROM tasks WHERE user_id=NEW.user_id AND id<>NEW.id AND status NOT IN ('completed','cancelled','archived','trashed') AND trashed_at IS NULL;
 IF lim IS NOT NULL AND used>=lim THEN RAISE EXCEPTION 'PLAN_LIMIT_ACTIVE_TASKS: The active-task allowance is reached. Complete or archive a task, or upgrade.'; END IF;
 -- Restore/undo cannot reactivate more rules than the account limit.
 rem_lim := (pst_plan_definition(NEW.user_id)->'limits'->>'activeReminders')::integer;
 IF rem_lim IS NOT NULL THEN
   SELECT count(*) INTO own_rules FROM reminder_rules WHERE task_id=NEW.id AND is_active;
   SELECT count(*) INTO active_rules FROM reminder_rules r JOIN tasks t ON t.id=r.task_id WHERE t.user_id=NEW.user_id AND t.id<>NEW.id AND r.is_active AND t.status NOT IN ('completed','cancelled','archived','trashed') AND t.trashed_at IS NULL;
   IF own_rules+active_rules>rem_lim THEN RAISE EXCEPTION 'PLAN_LIMIT_REMINDERS: The active-reminder allowance is reached. Disable extra rules before restoring.'; END IF;
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS pst_tasks_capacity ON tasks;
CREATE TRIGGER pst_tasks_capacity BEFORE INSERT OR UPDATE OF status,user_id,trashed_at ON tasks FOR EACH ROW EXECUTE FUNCTION pst_enforce_task_capacity();
CREATE OR REPLACE FUNCTION pst_enforce_rule_capacity() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE owner integer; def jsonb; lim integer; used integer; active_task boolean;
BEGIN
 IF NOT NEW.is_active THEN RETURN NEW; END IF;
 SELECT user_id,(status NOT IN ('completed','cancelled','archived','trashed') AND trashed_at IS NULL) INTO owner,active_task FROM tasks WHERE id=NEW.task_id;
 IF NOT active_task THEN RETURN NEW; END IF;
 PERFORM pg_advisory_xact_lock(73505,owner);
 def := pst_plan_definition(owner);
 IF NOT COALESCE((def->'features'->>'advancedReminders')::boolean,false) AND NEW.offset_minutes NOT IN (0,15,60,180,1440) THEN
   RAISE EXCEPTION 'PLAN_FEATURE_ADVANCED_REMINDERS: Custom reminder offsets require Pro. Standard presets remain available.';
 END IF;
 lim := (def->'limits'->>'activeReminders')::integer;
 SELECT count(*) INTO used FROM reminder_rules r JOIN tasks t ON t.id=r.task_id WHERE t.user_id=owner AND r.id<>NEW.id AND r.is_active AND t.status NOT IN ('completed','cancelled','archived','trashed') AND t.trashed_at IS NULL;
 IF lim IS NOT NULL AND used>=lim THEN RAISE EXCEPTION 'PLAN_LIMIT_REMINDERS: The active-reminder allowance is reached. Disable another reminder or upgrade.'; END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS pst_rules_capacity ON reminder_rules;
CREATE TRIGGER pst_rules_capacity BEFORE INSERT OR UPDATE OF is_active,offset_minutes,task_id ON reminder_rules FOR EACH ROW EXECUTE FUNCTION pst_enforce_rule_capacity();
CREATE OR REPLACE FUNCTION pst_enforce_mailbox_capacity() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE def jsonb; lim integer; used integer;
BEGIN
 IF NEW.status<>'active' THEN RETURN NEW; END IF;
 IF TG_OP='UPDATE' THEN
   IF OLD.status='active' AND OLD.user_id=NEW.user_id THEN RETURN NEW; END IF;
 END IF;
 PERFORM pg_advisory_xact_lock(73505,NEW.user_id);
 def := pst_plan_definition(NEW.user_id);
 IF NOT COALESCE((def->'features'->>'mailboxSync')::boolean,false) THEN RAISE EXCEPTION 'PLAN_FEATURE_MAILBOX: Mailbox connection requires Pro. Manual notice import remains free.'; END IF;
 lim := (def->'limits'->>'mailboxes')::integer;
 SELECT count(*) INTO used FROM oauth_connections WHERE user_id=NEW.user_id AND id<>NEW.id AND status='active';
 IF used>=lim THEN RAISE EXCEPTION 'PLAN_LIMIT_MAILBOX: Connected mailbox limit reached.'; END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS pst_mailbox_capacity ON oauth_connections;
CREATE TRIGGER pst_mailbox_capacity BEFORE INSERT OR UPDATE OF status,user_id ON oauth_connections FOR EACH ROW EXECUTE FUNCTION pst_enforce_mailbox_capacity();
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS binding_started_at timestamptz;
ALTER TABLE billing_support_requests ADD COLUMN IF NOT EXISTS provider_refund_id text;

ALTER TABLE billing_invoices ADD COLUMN IF NOT EXISTS refunded_minor integer NOT NULL DEFAULT 0;
-- Durable send leases prevent two processes using one reservation simultaneously.
ALTER TABLE billing_usage_keys ADD COLUMN IF NOT EXISTS dispatch_state text NOT NULL DEFAULT 'reserved';
ALTER TABLE billing_usage_keys ADD COLUMN IF NOT EXISTS dispatch_until timestamptz;
ALTER TABLE billing_usage_keys ADD COLUMN IF NOT EXISTS dispatch_provider text;
ALTER TABLE billing_usage_keys ADD COLUMN IF NOT EXISTS dispatch_lease text;
CREATE INDEX IF NOT EXISTS billing_usage_keys_owner_date_idx ON billing_usage_keys(user_id,metric,created_at);
CREATE INDEX IF NOT EXISTS billing_usage_keys_metric_date_idx ON billing_usage_keys(metric,created_at);
