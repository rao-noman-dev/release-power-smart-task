CREATE TABLE IF NOT EXISTS oauth_states (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL CHECK (provider IN ('gmail', 'outlook')),
  state_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS oauth_states_user_provider_idx ON oauth_states(user_id, provider);
CREATE INDEX IF NOT EXISTS oauth_states_expiry_idx ON oauth_states(expires_at);

CREATE TABLE IF NOT EXISTS oauth_connections (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_id INTEGER NOT NULL REFERENCES external_sources(id) ON DELETE CASCADE,
  provider TEXT NOT NULL CHECK (provider IN ('gmail', 'outlook')),
  account_email TEXT NOT NULL,
  access_token_encrypted TEXT NOT NULL,
  refresh_token_encrypted TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  scopes TEXT NOT NULL,
  sync_cursor TEXT,
  last_synced_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT oauth_connections_user_provider_account_uq UNIQUE(user_id, provider, account_email)
);
CREATE INDEX IF NOT EXISTS oauth_connections_user_idx ON oauth_connections(user_id);

ALTER TABLE scheduled_jobs ADD COLUMN IF NOT EXISTS idempotency_key TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS scheduled_jobs_idempotency_key_uq ON scheduled_jobs(idempotency_key);

ALTER TABLE tasks ADD COLUMN IF NOT EXISTS spawned_from_task_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL;
CREATE UNIQUE INDEX IF NOT EXISTS tasks_spawned_from_task_id_uq ON tasks(spawned_from_task_id);

CREATE UNIQUE INDEX IF NOT EXISTS external_notices_source_message_uq
  ON external_notices(external_source_id, external_message_id);
