-- Operator-controlled activation. Old provider records are retained, never auto-approved.
CREATE TABLE manual_payment_settings (
 id integer PRIMARY KEY CHECK(id=1), enabled boolean NOT NULL DEFAULT false,
 account_title text NOT NULL DEFAULT '', account_reference text NOT NULL DEFAULT '',
 instructions text NOT NULL DEFAULT '', pricing_approved boolean NOT NULL DEFAULT false,
 revision integer NOT NULL DEFAULT 1, updated_at timestamptz NOT NULL DEFAULT now(),
 updated_by integer REFERENCES users(id) ON DELETE SET NULL
);
INSERT INTO manual_payment_settings(id) VALUES(1);
CREATE TABLE manual_payment_reports (
 id uuid PRIMARY KEY, user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 request_key text NOT NULL, plan text NOT NULL CHECK(plan='pro_student'),
 amount_minor integer NOT NULL CHECK(amount_minor>0), currency text NOT NULL CHECK(currency='PKR'),
 duration_days integer NOT NULL CHECK(duration_days BETWEEN 1 AND 90),
 account_title text NOT NULL, account_reference text NOT NULL, instructions text NOT NULL,
 settings_revision integer NOT NULL,
 state text NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','submitted','approved','rejected','cancelled')),
 transaction_id text, transaction_hash text, sender_label text,
 claimed_paid_at timestamptz, submitted_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL DEFAULT(now()+interval '7 days'),
 reviewed_at timestamptz, reviewed_by integer REFERENCES users(id) ON DELETE SET NULL, review_note text,
 period_start timestamptz, period_end timestamptz,
 UNIQUE(user_id,request_key),
 CHECK(state NOT IN ('submitted','approved','rejected') OR (transaction_id IS NOT NULL AND transaction_hash IS NOT NULL AND claimed_paid_at IS NOT NULL AND submitted_at IS NOT NULL)),
 CHECK(state<>'approved' OR (reviewed_at IS NOT NULL AND period_start IS NOT NULL AND period_end>period_start))
);
CREATE UNIQUE INDEX manual_report_owner_transaction_uq ON manual_payment_reports(user_id,transaction_hash) WHERE transaction_hash IS NOT NULL;
CREATE INDEX manual_report_pending_idx ON manual_payment_reports(state,submitted_at);
CREATE INDEX manual_report_owner_idx ON manual_payment_reports(user_id,created_at);
-- Immutable approved receipt fingerprints prevent replay across accounts, even after erasure.
CREATE TABLE manual_payment_receipts (
 transaction_hash text PRIMARY KEY, report_id uuid UNIQUE NOT NULL,
 user_id integer REFERENCES users(id) ON DELETE SET NULL,
 amount_minor integer NOT NULL CHECK(amount_minor>0), currency text NOT NULL CHECK(currency='PKR'),
 approved_by integer REFERENCES users(id) ON DELETE SET NULL,
 approved_at timestamptz NOT NULL DEFAULT now(), period_start timestamptz NOT NULL,
 period_end timestamptz NOT NULL, CHECK(period_end>period_start)
);
CREATE TABLE manual_memberships (
 user_id integer PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 plan text NOT NULL DEFAULT 'pro_student' CHECK(plan='pro_student'),
 starts_at timestamptz, expires_at timestamptz,
 last_report_id uuid REFERENCES manual_payment_reports(id) ON DELETE SET NULL,
 approved_by integer REFERENCES users(id) ON DELETE SET NULL,
 suspended_at timestamptz, suspension_reason text,
 updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK(expires_at IS NULL OR starts_at IS NOT NULL AND expires_at>starts_at)
);
CREATE OR REPLACE FUNCTION pst_effective_plan(p_user integer) RETURNS text LANGUAGE plpgsql STABLE AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM users WHERE id=p_user AND deletion_requested_at IS NULL) THEN RETURN 'free'; END IF;
 IF EXISTS(SELECT 1 FROM manual_memberships WHERE user_id=p_user AND suspended_at IS NOT NULL) THEN RETURN 'free'; END IF;
 IF EXISTS(SELECT 1 FROM manual_memberships m
   JOIN manual_payment_reports r ON r.id=m.last_report_id AND r.user_id=m.user_id AND r.state='approved'
   JOIN manual_payment_receipts v ON v.report_id=r.id AND v.user_id=m.user_id
   WHERE m.user_id=p_user AND m.starts_at<=now() AND m.expires_at>now() AND m.suspended_at IS NULL AND m.expires_at=v.period_end AND r.period_end=v.period_end AND r.amount_minor=v.amount_minor)
 THEN RETURN 'pro_student'; END IF;
 IF EXISTS(SELECT 1 FROM billing_grants WHERE user_id=p_user AND plan='pro_student' AND revoked_at IS NULL AND expires_at>now()) THEN RETURN 'pro_student'; END IF;
 -- Stripe/Safepay states intentionally do not grant access in manual-only mode.
 RETURN 'free';
END $$;
CREATE TRIGGER pst_erasure_guard BEFORE INSERT ON manual_payment_reports FOR EACH ROW EXECUTE FUNCTION pst_deny_erasing_owner();
CREATE TRIGGER pst_erasure_guard BEFORE INSERT ON manual_memberships FOR EACH ROW EXECUTE FUNCTION pst_deny_erasing_owner();
CREATE TRIGGER pst_erasure_guard BEFORE INSERT ON manual_payment_receipts FOR EACH ROW EXECUTE FUNCTION pst_deny_erasing_owner();
-- Do not replay previously queued provider events into subscription activation.
UPDATE billing_events SET status='needs_review',last_error='Manual approval mode: provider events do not activate access.' WHERE status='pending';
-- Explicitly preserve the original wall-clock value. It has no reliable timezone metadata.
-- Existing rows stay marked legacy until an operator supplies the actual historical DB zone.
ALTER TABLE audit_logs ADD COLUMN recorded_at timestamptz;
CREATE OR REPLACE FUNCTION pst_audit_record_instant() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.recorded_at := clock_timestamp(); RETURN NEW; END $$;
CREATE TRIGGER pst_audit_record_instant BEFORE INSERT ON audit_logs FOR EACH ROW EXECUTE FUNCTION pst_audit_record_instant();
