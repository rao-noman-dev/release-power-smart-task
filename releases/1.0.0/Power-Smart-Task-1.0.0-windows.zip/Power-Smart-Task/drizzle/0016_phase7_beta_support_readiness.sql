-- Additive Phase 7: no existing plan, receiving account, credentials or task data is changed.
CREATE TABLE IF NOT EXISTS launch_settings (
 id integer PRIMARY KEY CHECK(id=1), stage text NOT NULL DEFAULT 'development' CHECK(stage IN ('development','private_beta','paid_pilot','release_candidate')),
 participant_limit integer NOT NULL DEFAULT 30 CHECK(participant_limit BETWEEN 1 AND 1000), support_email text NOT NULL DEFAULT '',
 revision integer NOT NULL DEFAULT 1, updated_at timestamptz NOT NULL DEFAULT now(), updated_by integer REFERENCES users(id) ON DELETE SET NULL
);
INSERT INTO launch_settings(id) VALUES(1) ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS beta_invitations (
 id uuid PRIMARY KEY, email text NOT NULL UNIQUE, cohort text NOT NULL CHECK(cohort IN ('private_beta','paid_pilot')),
 state text NOT NULL DEFAULT 'invited' CHECK(state IN ('invited','accepted','revoked')), expires_at timestamptz NOT NULL,
 created_by integer REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(),
 claimed_by integer REFERENCES users(id) ON DELETE SET NULL, revision integer NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS beta_memberships (
 user_id integer PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, cohort text NOT NULL CHECK(cohort IN ('private_beta','paid_pilot')),
 state text NOT NULL CHECK(state IN ('enrolled','withdrawn','revoked')), consent_version text NOT NULL,
 enrolled_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS support_tickets (
 id uuid PRIMARY KEY, user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE, request_key uuid NOT NULL,
 kind text NOT NULL CHECK(kind IN ('bug','feedback','question')), title text NOT NULL CHECK(length(title) BETWEEN 5 AND 160),
 state text NOT NULL DEFAULT 'open' CHECK(state IN ('open','investigating','waiting_customer','resolved','closed')),
 severity text NOT NULL DEFAULT 'normal' CHECK(severity IN ('normal','high','critical')), launch_blocker boolean NOT NULL DEFAULT false,
 consent_version text NOT NULL, revision integer NOT NULL DEFAULT 1, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(user_id,request_key)
);
CREATE INDEX IF NOT EXISTS support_tickets_queue ON support_tickets(state,updated_at DESC,id);
CREATE INDEX IF NOT EXISTS support_tickets_owner ON support_tickets(user_id,created_at DESC,id);
CREATE TABLE IF NOT EXISTS support_messages (
 id bigserial PRIMARY KEY, ticket_id uuid NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
 author_id integer REFERENCES users(id) ON DELETE SET NULL, author_role text NOT NULL CHECK(author_role IN ('customer','operator')),
 request_key uuid NOT NULL, body text NOT NULL CHECK(length(body) BETWEEN 10 AND 4000), created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(ticket_id,request_key)
);
CREATE TABLE IF NOT EXISTS release_evidence (
 key text PRIMARY KEY CHECK(key IN ('fullTypecheck','productionBuild','unitTests','databaseIsolation','browserJourney','mobileAccessibility','manualPaymentWorkflow','providerDelivery','privacyExport','accountErasure','backupRestore','dependencyReview','operatorPolicies','stagingSmoke','rollbackDrill')),
 status text NOT NULL CHECK(status IN ('not_run','passed','failed')), reference text, artifact_sha256 text, checked_at timestamptz, note text NOT NULL,
 recorded_by integer REFERENCES users(id) ON DELETE SET NULL, recorded_at timestamptz NOT NULL DEFAULT now(), revision integer NOT NULL DEFAULT 1
);
-- Prevent a request racing account erasure from inserting new private support/enrollment data.
CREATE OR REPLACE FUNCTION phase7_owner_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM pg_advisory_xact_lock(73505,NEW.user_id);
 IF EXISTS(SELECT 1 FROM users WHERE id=NEW.user_id AND deletion_requested_at IS NOT NULL) THEN RAISE EXCEPTION 'ACCOUNT_ERASING'; END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS phase7_ticket_owner_guard ON support_tickets;
CREATE TRIGGER phase7_ticket_owner_guard BEFORE INSERT OR UPDATE ON support_tickets FOR EACH ROW EXECUTE FUNCTION phase7_owner_guard();
DROP TRIGGER IF EXISTS phase7_member_owner_guard ON beta_memberships;
CREATE TRIGGER phase7_member_owner_guard BEFORE INSERT OR UPDATE ON beta_memberships FOR EACH ROW EXECUTE FUNCTION phase7_owner_guard();

CREATE OR REPLACE FUNCTION phase7_message_owner_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE account_id integer;
BEGIN
 SELECT user_id INTO account_id FROM support_tickets WHERE id=NEW.ticket_id;
 IF account_id IS NULL THEN RAISE EXCEPTION 'SUPPORT_TICKET_NOT_FOUND'; END IF;
 PERFORM pg_advisory_xact_lock(73505,account_id);
 IF EXISTS(SELECT 1 FROM users WHERE id=account_id AND deletion_requested_at IS NOT NULL) THEN RAISE EXCEPTION 'ACCOUNT_ERASING'; END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS phase7_message_owner_guard ON support_messages;
CREATE TRIGGER phase7_message_owner_guard BEFORE INSERT ON support_messages FOR EACH ROW EXECUTE FUNCTION phase7_message_owner_guard();
