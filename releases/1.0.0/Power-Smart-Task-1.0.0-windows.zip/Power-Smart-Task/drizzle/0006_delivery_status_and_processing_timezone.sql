-- Convert legacy timezone-less worker leases as UTC, but do not reinterpret
-- TIMESTAMPTZ values on fresh installations that were created from the schema.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = current_schema()
      AND table_name = 'scheduled_jobs'
      AND column_name = 'processing_started_at'
      AND data_type = 'timestamp without time zone'
  ) THEN
    ALTER TABLE scheduled_jobs
      ALTER COLUMN processing_started_at TYPE TIMESTAMPTZ
      USING processing_started_at AT TIME ZONE 'UTC';
  END IF;
END $$;

-- New delivery rows must never default to a successful status.
ALTER TABLE IF EXISTS notification_deliveries
  ALTER COLUMN delivery_status SET DEFAULT 'queued';
