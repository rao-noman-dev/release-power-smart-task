ALTER TABLE oauth_connections
  ADD COLUMN IF NOT EXISTS sync_lease_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS oauth_connections_sync_due_idx
  ON oauth_connections(status, last_synced_at, sync_lease_at)
  WHERE status = 'active';
