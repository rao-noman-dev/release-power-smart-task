-- Notification delivery timestamps are compared against user-local UTC day bounds.
-- Convert legacy timezone-less values as UTC, but leave fresh TIMESTAMPTZ schemas untouched.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema()
      AND table_name = 'notification_deliveries'
      AND column_name = 'sent_at'
      AND data_type = 'timestamp without time zone'
  ) THEN
    ALTER TABLE notification_deliveries
      ALTER COLUMN sent_at TYPE TIMESTAMPTZ
      USING sent_at AT TIME ZONE 'UTC';
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS notification_deliveries_user_sent_status_idx
  ON notification_deliveries(user_id, sent_at, delivery_status);

CREATE INDEX IF NOT EXISTS notification_deliveries_provider_message_idx
  ON notification_deliveries(provider, provider_message_id);

-- Preserve every historical delivery row. Older duplicate keys are cleared so only
-- the preferred accepted/delivered (or newest) row participates in the unique index.
WITH ranked AS (
  SELECT id, ROW_NUMBER() OVER (
    PARTITION BY idempotency_key
    ORDER BY CASE WHEN delivery_status IN ('accepted', 'delivered') THEN 0 ELSE 1 END, sent_at DESC, id DESC
  ) AS row_number
  FROM notification_deliveries
  WHERE idempotency_key IS NOT NULL
)
UPDATE notification_deliveries d
SET idempotency_key = NULL
FROM ranked r
WHERE d.id = r.id AND r.row_number > 1;

CREATE UNIQUE INDEX IF NOT EXISTS notification_deliveries_idempotency_uq
  ON notification_deliveries(idempotency_key);

-- The older partial unique index is redundant after the canonical schema index exists.
DROP INDEX IF EXISTS notification_deliveries_idempotency_key_uq;
