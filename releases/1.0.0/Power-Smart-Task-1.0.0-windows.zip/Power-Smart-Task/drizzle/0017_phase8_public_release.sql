-- Additive publication control. No existing plan, task, payment, pilot stage or credential is altered.
CREATE TABLE public_launch_control (
 id integer PRIMARY KEY CHECK (id=1),
 mode text NOT NULL DEFAULT 'closed' CHECK (mode IN ('closed','open','maintenance')),
 revision integer NOT NULL DEFAULT 1 CHECK (revision>0),
 public_origin text,
 firebase_project_id text,
 release_commit text CHECK (release_commit IS NULL OR release_commit ~ '^[a-f0-9]{40}$'),
 release_image text,
 evidence_sha256 text CHECK (evidence_sha256 IS NULL OR evidence_sha256 ~ '^[a-f0-9]{64}$'),
 opened_at timestamptz,
 changed_at timestamptz NOT NULL DEFAULT now(),
 changed_by integer REFERENCES users(id) ON DELETE SET NULL,
 CHECK (mode<>'open' OR (public_origin IS NOT NULL AND firebase_project_id IS NOT NULL AND release_commit IS NOT NULL AND release_image IS NOT NULL AND evidence_sha256 IS NOT NULL AND opened_at IS NOT NULL))
);
INSERT INTO public_launch_control(id) VALUES(1);
CREATE TABLE public_launch_events (
 id bigserial PRIMARY KEY,
 request_id uuid NOT NULL UNIQUE,
 actor_id integer REFERENCES users(id) ON DELETE SET NULL,
 request_fingerprint text NOT NULL CHECK (request_fingerprint ~ '^[a-f0-9]{64}$'),
 previous_mode text NOT NULL,
 next_mode text NOT NULL CHECK (next_mode IN ('closed','open','maintenance')),
 reason text NOT NULL CHECK (length(reason) BETWEEN 10 AND 500),
 release_commit text,
 evidence_sha256 text,
 revision integer NOT NULL,
 recorded_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX public_launch_events_recorded_idx ON public_launch_events(recorded_at DESC);
-- No grants, no payment approvals, no public users are created by this migration.
