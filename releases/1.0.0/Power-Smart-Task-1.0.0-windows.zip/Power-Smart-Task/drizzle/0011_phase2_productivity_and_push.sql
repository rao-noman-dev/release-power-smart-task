-- Phase 2: additive, owner-scoped productivity and notification preferences.
ALTER TABLE user_profiles
  ADD COLUMN IF NOT EXISTS email_alerts_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS in_app_alerts_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS web_push_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS critical_bypass_quiet_hours BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS digest_mode BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS weekly_digest_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS weekly_digest_time TEXT NOT NULL DEFAULT '09:00';

ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS trashed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS pre_trash_status TEXT;
CREATE INDEX IF NOT EXISTS tasks_owner_trashed_idx ON tasks(user_id, trashed_at);

ALTER TABLE scheduled_jobs ADD COLUMN IF NOT EXISTS web_push_attempted_at TIMESTAMPTZ;

ALTER TABLE notifications ADD COLUMN IF NOT EXISTS scheduled_job_id INTEGER REFERENCES scheduled_jobs(id) ON DELETE SET NULL;
CREATE UNIQUE INDEX IF NOT EXISTS notifications_scheduled_job_uq ON notifications(scheduled_job_id);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS push_subscriptions_user_idx ON push_subscriptions(user_id);

CREATE TABLE IF NOT EXISTS saved_task_filters (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  definition TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS saved_task_filters_user_idx ON saved_task_filters(user_id);

CREATE TABLE IF NOT EXISTS task_templates (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  definition TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS task_templates_user_idx ON task_templates(user_id);

CREATE TABLE IF NOT EXISTS task_history (
  id SERIAL PRIMARY KEY,
  task_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  details TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS task_history_user_task_time_idx ON task_history(user_id, task_id, created_at);

CREATE TABLE IF NOT EXISTS weekly_digest_runs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  week_start TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'processing',
  attempt_count INTEGER NOT NULL DEFAULT 0,
  processing_started_at TIMESTAMPTZ,
  sent_at TIMESTAMPTZ,
  CONSTRAINT weekly_digest_runs_owner_week_uq UNIQUE(user_id, week_start)
);
