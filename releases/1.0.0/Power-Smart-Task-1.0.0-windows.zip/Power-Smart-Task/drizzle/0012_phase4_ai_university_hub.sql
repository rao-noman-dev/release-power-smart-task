-- Phase 4 additive upgrade. No existing OAuth tokens, tasks or notices are removed.
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS ai_external_processing_consent boolean NOT NULL DEFAULT false;

ALTER TABLE external_notices ADD COLUMN IF NOT EXISTS content_fingerprint text;
ALTER TABLE external_notices ADD COLUMN IF NOT EXISTS source_kind text NOT NULL DEFAULT 'mailbox';
ALTER TABLE external_notices ADD COLUMN IF NOT EXISTS source_url text;
ALTER TABLE external_notices ADD COLUMN IF NOT EXISTS summary text;
ALTER TABLE external_notices ADD COLUMN IF NOT EXISTS urgency text NOT NULL DEFAULT 'medium';
ALTER TABLE external_notices ADD COLUMN IF NOT EXISTS action_required text;
ALTER TABLE external_notices ADD COLUMN IF NOT EXISTS analysis_mode text NOT NULL DEFAULT 'local';

-- A per-user fingerprint detects the same notice imported via multiple channels.
-- NULL fingerprints on historical rows remain valid and are not retroactively guessed.
CREATE UNIQUE INDEX IF NOT EXISTS external_notices_user_fingerprint_uq
  ON external_notices(user_id, content_fingerprint);
CREATE INDEX IF NOT EXISTS external_notices_user_received_idx
  ON external_notices(user_id, received_at);

CREATE TABLE IF NOT EXISTS ai_daily_usage (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day_key text NOT NULL,
  used integer NOT NULL DEFAULT 0 CHECK (used >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ai_daily_usage_user_day_unique UNIQUE (user_id, day_key)
);
CREATE INDEX IF NOT EXISTS ai_daily_usage_user_day_idx ON ai_daily_usage(user_id, day_key);
