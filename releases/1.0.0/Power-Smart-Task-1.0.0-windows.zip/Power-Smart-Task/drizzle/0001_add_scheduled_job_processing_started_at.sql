ALTER TABLE IF EXISTS scheduled_jobs
  ADD COLUMN IF NOT EXISTS processing_started_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS scheduled_jobs_due_pending_idx
  ON scheduled_jobs (scheduled_for, id)
  WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS scheduled_jobs_processing_lease_idx
  ON scheduled_jobs (processing_started_at)
  WHERE status = 'processing';
