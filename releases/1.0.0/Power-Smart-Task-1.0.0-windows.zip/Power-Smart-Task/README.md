# Power Smart Task 1.0.0

This folder is the app you run on your own computer. It is not the source repository.

1. Install Node.js 22 or newer.
2. Install PostgreSQL and create an empty database.
3. Unzip this folder.
4. Double-click Start-Power-Smart-Task.bat.
5. The first time, copy .env.example to .env and fill in the database settings.

The app opens at http://127.0.0.1:3000 on this computer only. JazzCash payment collection stays closed. An administrator can still grant complimentary Pro to an account that has already signed up.
