@echo off
cd /d "%~dp0"
where node >nul 2>&1 || (
  echo Install Node.js 22 or newer from https://nodejs.org and then run this file again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing the app runtime. An internet connection is needed this first time.
  call npm.cmd install --omit=dev --no-audit --no-fund
  if errorlevel 1 (
    pause
    exit /b 1
  )
)
if not exist .env (
  echo This folder needs your own .env file. A blank template is .env.example.
  echo Put the PostgreSQL settings there. Do not put a JazzCash PIN, OTP, or payment password in it.
  echo JazzCash payment collection stays closed.
  notepad .env.example
  pause
  exit /b 1
)
echo Preparing the local database.
node --env-file=.env dist\migrate.mjs
if errorlevel 1 (
  pause
  exit /b 1
)
set NODE_ENV=development
set PST_LOCAL_PACKAGE=true
set HOST=127.0.0.1
start "" http://127.0.0.1:3000
node --env-file=.env dist\server.mjs
pause
